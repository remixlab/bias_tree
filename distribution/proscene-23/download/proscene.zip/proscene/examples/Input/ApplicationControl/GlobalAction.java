public enum GlobalAction {
  CHANGE_COLOR, 
  CHANGE_SHAPE
}
