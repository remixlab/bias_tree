package remixlab.bias.agent;

import remixlab.bias.core.Agent;
import remixlab.bias.core.InputHandler;

public class InteractiveMotionAgent extends Agent {
	public InteractiveMotionAgent(InputHandler inputHandler, String name) {
		super(inputHandler, name);
	}

}
