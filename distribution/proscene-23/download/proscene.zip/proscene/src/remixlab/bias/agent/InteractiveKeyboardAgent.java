package remixlab.bias.agent;

import remixlab.bias.core.*;

public class InteractiveKeyboardAgent extends Agent {
	public InteractiveKeyboardAgent(InputHandler inputHandler, String name) {
		super(inputHandler, name);
	}
}
